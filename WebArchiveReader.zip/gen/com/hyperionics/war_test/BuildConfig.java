/** Automatically generated file. DO NOT MODIFY */
package com.hyperionics.war_test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}